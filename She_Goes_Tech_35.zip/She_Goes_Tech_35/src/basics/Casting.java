package basics;

public class Casting {
    public static void main(String[] args) {

        //Widening
        int num1 = 100;
        System.out.println(num1);

        float num2 = num1;
        System.out.println(num2);

        //basics.Casting
        float temp = 36.6f;
        System.out.println(temp);

        int temp2 = (int) temp;
        System.out.println(temp2);

    }
}
