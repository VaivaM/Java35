package basics;

public class BranchingStatements {
    public static void main(String[] args) {

        for (int i = 0; i < 10; i++) {
            System.out.println("Hello World!");
            if (i == 1) {
                break;
            }
        }

        for (int i = 0; i < 10; i++){
            System.out.println(i);
            if(i == 8){
                continue;
            }
        }
    }
}
