package basics;

public class Variables {
    public static void main(String[] args) {
        //Declaring new variable of type int (integer)
        int number;

        //Initialization of number variable
        number = 10;

        //Accessing number variables value
        System.out.println(number);

        //Declaring and Initializing new variable in one line
        int age = 75;
        System.out.println("age = " + age);
    }
}