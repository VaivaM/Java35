package basics;

public class HelloWorld {
    public static void main(String[] args) {
        System.out.println("Hello Vaiva!");
        //This is single-line comment
        /*
        This is
        Multi-line
        Comment
         */

    }
}
