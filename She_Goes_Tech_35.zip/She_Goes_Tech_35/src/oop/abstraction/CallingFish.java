package oop.abstraction;

public class CallingFish {
    public static void main(String[] args) {

        Fish fish = new Fish("Black","Bread","Water",4,2);
        fish.printPetInfo();

    }
}
