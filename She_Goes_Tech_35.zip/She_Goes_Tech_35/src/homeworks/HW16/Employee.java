package homeworks.HW16;

public class Employee extends Member {

    private String specialization;

    public Employee(String name, int age, String phoneNumber, String street, int salary, String worker) {
        super(name, age, phoneNumber, street, salary);
        this.specialization = specialization;
    }
}
