package homeworks;

public class HW6 {
    public static void main(String[] args) {

 /*        Write an application, that will print the full latin alphabet
        (upper case letters) in alphabetical order. Each letter should be printed in new line.*/

        for (char letters = 'A'; letters <= 'Z'; letters++) {
            System.out.println(letters);

        }
    }
 }
